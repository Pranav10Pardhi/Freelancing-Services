Add your profile image as profile.jpg and resume as resume.pdf in this folder.
